<?php
// Heading
$_['heading_title']     = 'Usuários';

// Text
$_['text_success']      = 'Usuários modificados com sucesso!';
$_['text_list']         = 'Listando usuários';
$_['text_add']          = 'Novo usuário';
$_['text_edit']         = 'Editando usuário';

// Column
$_['column_username']   = 'Usuário';
$_['column_status']     = 'Situação';
$_['column_date_added'] = 'Cadastro';
$_['column_action']     = 'Ação';

// Entry
$_['entry_username']   	= 'Usuário';
$_['entry_user_group'] 	= 'Grupo de usuários';
$_['entry_password']   	= 'Senha';
$_['entry_confirm']    	= 'Repetir a senha';
$_['entry_firstname']  	= 'Nome';
$_['entry_lastname']   	= 'Sobrenome';
$_['entry_email']      	= 'E-mail';
$_['entry_image']      	= 'Avatar';
$_['entry_status']     	= 'Situação';

// Error
$_['error_permission'] 	= 'Atenção: Você não tem permissão para modificar os usuários!';
$_['error_account']    	= 'Atenção: Você não pode excluir sua própria conta!';
$_['error_exists']     	= 'Atenção: O usuário já está em uso!';
$_['error_username']   	= 'O usuário deve ter entre 3 e 20 caracteres!';
$_['error_password']   	= 'A senha deve ter entre 4 e 20 caracteres!';
$_['error_confirm']    	= 'A senha e repetida esta errada!';
$_['error_firstname']  	= 'O nome deve ter entre 1 e 32 caracteres!';
$_['error_lastname']   	= 'O sobrenome deve ter entre 1 e 32 caracteres!';